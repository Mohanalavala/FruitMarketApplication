package com.mohanalavala.FruitMarketplaceApplication.model;

public enum FruitType {

	BERRIES,
	POMES,
	DRUPES,
	CITRUS,
	TROPICAL,
	PEPO
}
