package com.mohanalavala.FruitMarketplaceApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FruitMarketplaceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FruitMarketplaceApplication.class, args);
	}

}
