package com.mohanalavala.FruitMarketplaceApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruitMarketplaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
